﻿#include "Render.h"
#include <Windows.h>
#include <GL\GL.h>
#include <GL\GLU.h>
#include <iostream>
#include <iomanip>
#include <sstream>
#include "GUItextRectangle.h"

#define A 



#ifdef _DEBUG
#include <Debugapi.h> 
struct debug_print
{
	template<class C>
	debug_print& operator<<(const C& a)
	{
		OutputDebugStringA((std::stringstream() << a).str().c_str());
		return *this;
	}
} debout;
#else
struct debug_print
{
	template<class C>
	debug_print& operator<<(const C& a)
	{
		return *this;
	}
} debout;
#endif

//библиотека для разгрузки изображений
//https://github.com/nothings/stb
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

//внутренняя логика "движка"
#include "MyOGL.h"
extern OpenGL gl;
#include "Light.h"
Light light;
#include "Camera.h"
Camera camera;


bool texturing = true;
bool lightning = true;
bool alpha = false;


//переключение режимов освещения, текстурирования, альфаналожения
void switchModes(OpenGL *sender, KeyEventArg arg)
{
	//конвертируем код клавиши в букву
	auto key = LOWORD(MapVirtualKeyA(arg.key, MAPVK_VK_TO_CHAR));

	switch (key)
	{
	case 'L':
		lightning = !lightning;
		break;
	case 'T':
		texturing = !texturing;
		break;
	case 'A':
		alpha = !alpha;
		break;
	}
}

//Текстовый прямоугольничек в верхнем правом углу.
//OGL не предоставляет возможности для хранения текста
//внутри этого класса создается картинка с текстом (через виндовый GDI),
//в виде текстуры накладывается на прямоугольник и рисуется на экране.
//Это самый простой способ что то написать на экране
//но ооооочень не оптимальный
GuiTextRectangle text;

//айдишник для текстуры
GLuint texId;
//выполняется один раз перед первым рендером
void initRender()
{
	//==============НАСТРОЙКА ТЕКСТУР================
	//4 байта на хранение пикселя
	glPixelStorei(GL_UNPACK_ALIGNMENT, 4);

	//просим сгенерировать нам Id для текстуры
	//и положить его в texId
	glGenTextures(1, &texId);

	//делаем текущую текстуру активной
	//все, что ниже будет применено texId текстуре.
	glBindTexture(GL_TEXTURE_2D, texId);


	int x, y, n;

	//загружаем картинку
	//см. #include "stb_image.h" 
	unsigned char* data = stbi_load("texture.png", &x, &y, &n, 4);
	//x - ширина изображения
	//y - высота изображения
	//n - количество каналов
	//4 - нужное нам количество каналов
	//пиксели будут хранится в памяти [R-G-B-A]-[R-G-B-A]-[..... 
	// по 4 байта на пиксель - по байту на канал
	//пустые каналы будут равны 255

	//Картинка хранится в памяти перевернутой 
	//так как ее начало в левом верхнем углу
	//по этому мы ее переворачиваем -
	//меняем первую строку с последней,
	//вторую с предпоследней, и.т.д.
	unsigned char* _tmp = new unsigned char[x * 4]; //времянка
	for (int i = 0; i < y / 2; ++i)
	{
		std::memcpy(_tmp, data + i * x * 4, x * 4);//переносим строку i в времянку
		std::memcpy(data + i * x * 4, data + (y - 1 - i) * x * 4, x * 4); //(y-1-i)я строка -> iя строка
		std::memcpy(data + (y - 1 - i) * x * 4, _tmp, x * 4); //времянка -> (y-1-i)я строка
	}
	delete[] _tmp;


	//загрузка изображения в видеопамять
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, x, y, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);

	//выгрузка изображения из опперативной памяти
	stbi_image_free(data);


	//настройка режима наложения текстур
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
												  //GL_REPLACE -- полная замена политога текстурой
	//настройка тайлинга
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

	//настройка фильтрации
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	//======================================================

	//================НАСТРОЙКА КАМЕРЫ======================
	camera.caclulateCameraPos();

	//привязываем камеру к событиям "движка"
	gl.WheelEvent.reaction(&camera, &Camera::Zoom);
	gl.MouseMovieEvent.reaction(&camera, &Camera::MouseMovie);
	gl.MouseLeaveEvent.reaction(&camera, &Camera::MouseLeave);
	gl.MouseLdownEvent.reaction(&camera, &Camera::MouseStartDrag);
	gl.MouseLupEvent.reaction(&camera, &Camera::MouseStopDrag);
	//==============НАСТРОЙКА СВЕТА===========================
	//привязываем свет к событиям "движка"
	gl.MouseMovieEvent.reaction(&light, &Light::MoveLight);
	gl.KeyDownEvent.reaction(&light, &Light::StartDrug);
	gl.KeyUpEvent.reaction(&light, &Light::StopDrug);
	//========================================================
	//====================Прочее==============================
	gl.KeyDownEvent.reaction(switchModes);
	text.setSize(512, 180);
	//========================================================
	   

	camera.setPosition(2, 1.5, 1.5);
}

double* normal(const double a1[], const double a2[], const double b2[]) {

	double* normalvect = new double[3]; // Динамическое выделение памяти

	double vectorA[]{ a2[0] - a1[0], a2[1] - a1[1], a2[2] - a1[2] };
	double vectorB[]{ b2[0] - a1[0], b2[1] - a1[1], b2[2] - a1[2] };

	double cross[]{ vectorA[1] * vectorB[2] - vectorA[2] * vectorB[1],
					  vectorA[2] * vectorB[0] - vectorA[0] * vectorB[2],
					  vectorA[0] * vectorB[1] - vectorA[1] * vectorB[0]
	};

	double length = sqrt(cross[0] * cross[0] + cross[1] * cross[1] + cross[2] * cross[2]);

	normalvect[0] = cross[0] / length;
	normalvect[1] = cross[1] / length;
	normalvect[2] = cross[2] / length;

	return normalvect;
}

// Функция для отрисовки вектора нормали к треугольнику
void normalVis(const double A2[], const double B2[], const double C2[]) {
	double* n = normal(A2, B2, C2); // Получение указателя на динамически выделенную память

	double center[]{ (A2[0] + B2[0] + C2[0]) / 3.0, (A2[1] + B2[1] + C2[1]) / 3.0, (A2[2] + B2[2] + C2[2]) / 3.0 };
	double N_end[]{ center[0] + n[0], center[1] + n[1], center[2] + n[2] };

	double center_arr[3] = { center[0],center[1],center[2] };
	double N_end_arr[3] = { N_end[0],N_end[1],N_end[2] };

	glBegin(GL_LINES);
	glColor3d(1, 0, 0);
	glVertex3dv(center_arr);
	glVertex3dv(N_end_arr);
	glEnd();

	delete[] n; // Освобождение выделенной памяти
}

void normalSq(const double a[], const double b[], const double c[], const double d[]) {
	// Вычисляем нормаль по двум сторонам квадрата (треугольник a-b-d)
	double* n = normal(a, b, d);

	// Центр квадрата = среднее из 4-х вершин
	double center[]{
		(a[0] + b[0] + c[0] + d[0]) / 4.0,
		(a[1] + b[1] + c[1] + d[1]) / 4.0,
		(a[2] + b[2] + c[2] + d[2]) / 4.0
	};

	double N_end[]{
		center[0] + n[0],
		center[1] + n[1],
		center[2] + n[2]
	};

	glBegin(GL_LINES);
	glColor3d(1, 0, 0);
	glVertex3dv(center);
	glVertex3dv(N_end);
	glEnd();

	delete[] n;
}




void Render(double delta_time)
{    
	glEnable(GL_DEPTH_TEST);
	
	//натройка камеры и света
	//в этих функциях находятся OGLные функции
	//которые устанавливают параметры источника света
	//и моделвью матрицу, связанные с камерой.

	if (gl.isKeyPressed('F')) //если нажата F - свет из камеры
	{
		light.SetPosition(camera.x(), camera.y(), camera.z());
	}
	camera.SetUpCamera();
	light.SetUpLight();


	//рисуем оси
	gl.DrawAxes();

	glDisable(GL_LIGHTING);
	glDisable(GL_TEXTURE_2D);
	glDisable(GL_BLEND);
	

	//включаем режимы, в зависимости от нажания клавиш. см void switchModes(OpenGL *sender, KeyEventArg arg)
	if (lightning)
		glEnable(GL_LIGHTING);
	if (texturing)
	{
		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, 0); //сбрасываем текущую текстуру
	}
		
	if (alpha)
	{
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	}
		
	//=============НАСТРОЙКА МАТЕРИАЛА==============


	//настройка материала, все что рисуется ниже будет иметь этот метериал.
	//массивы с настройками материала
	float  amb[] = { 0.2, 0.2, 0.1, 1. };
	float dif[] = { 0.4, 0.65, 0.5, 1. };
	float spec[] = { 0.9, 0.8, 0.3, 1. };
	float sh = 0.2f * 256;

	//фоновая
	glMaterialfv(GL_FRONT, GL_AMBIENT, amb);
	//дифузная
	glMaterialfv(GL_FRONT, GL_DIFFUSE, dif);
	//зеркальная
	glMaterialfv(GL_FRONT, GL_SPECULAR, spec); 
	//размер блика
	glMaterialf(GL_FRONT, GL_SHININESS, sh);

	//чтоб было красиво, без квадратиков (сглаживание освещения)
	glShadeModel(GL_SMOOTH); //закраска по Гуро      
			   //(GL_SMOOTH - плоская закраска)

	//============ РИСОВАТЬ ТУТ ==============

	
	double A1[]{ 1, 0, 0 };
	double B1[]{ 1, -3, 0 };
	double C1[]{ -1, -2, 0 };
	double D1[]{ -3, 8, 0 };
	double E1[]{ -8, 3, 0 };
	double F1[]{ -3, -6, 0 };
	double G1[]{ 2, -8, 0 };
	double K1[]{ 7, 1, 0 };

	double A2[]{ 1, 0, 3 };
	double B2[]{ 1, -3, 3 };
	double C2[]{ -1, -2, 3 };
	double D2[]{ -3, 8, 3 };
	double E2[]{ -8, 3, 3 };
	double F2[]{ -3, -6, 3 };
	double G2[]{ 2, -8, 3 };
	double K2[]{ 7, 1, 3 };


	const double PI = 3.14159265358979323846;

	bool b_light = glIsEnabled(GL_LIGHTING);
	if (b_light)
		glDisable(GL_LIGHTING);

	//для треугольников
	normalVis(A1, B1, C1);
	normalVis(A2, C2, B2);
	normalVis(A2, B2, K2);
	normalVis(A1, K1, B1);
	normalVis(A2, B2, K2);
	//для квадратов
	normalSq(A1, C1, E1, D1);
	normalSq(A2, D2, E2, C2);
	normalSq(C1, B1, G1, F1);
	normalSq(C2, F2, G2, B2);
	normalSq(K1, K2, B2, B1);
	normalSq(F1, F2, C2, C1);
	normalSq(D1, D2, A2, A1);
	normalSq(B1, B2, G2, G1);
	normalSq(C1, C2, E2, E1);
	normalSq(A1, A2, K2, K1);
	normalSq(G1, G2, F2, F1);
	normalSq(E1, E2, D2, D1);

	if (b_light)
		glEnable(GL_LIGHTING);

	glBegin(GL_TRIANGLES);

	glColor3d(0.7, 0.2, 0);
	glNormal3dv(normal(A1, B1, C1));
	glVertex3dv(A1);
	glVertex3dv(B1);
	glVertex3dv(C1);

	glNormal3dv(normal(A2, C2, B2));
	glVertex3dv(A2);
	glVertex3dv(B2);
	glVertex3dv(C2);

	glColor3d(1, 0, 0);
	glNormal3dv(normal(A1, K1, B1));
	glVertex3dv(A1);
	glVertex3dv(B1);
	glVertex3dv(K1);
	
	glNormal3dv(normal(A2, B2, K2));
	glVertex3dv(A2);
	glVertex3dv(B2);
	glVertex3dv(K2);

	glEnd();

	glBegin(GL_QUADS);

	glColor3d(0, 1, 0);
	glNormal3dv(normal(A1, C1, D1));
	glVertex3dv(A1);
	glVertex3dv(D1);
	glVertex3dv(E1);
	glVertex3dv(C1);

	glNormal3dv(normal(A2,D2,C2));
	glVertex3dv(A2);
	glVertex3dv(D2);
	glVertex3dv(E2);
	glVertex3dv(C2);

	glColor3d(0, 0, 1);
	glNormal3dv(normal(C1, B1, F1));;
	glVertex3dv(C1);
	glVertex3dv(F1);
	glVertex3dv(G1);
	glVertex3dv(B1);

	glNormal3dv(normal(C2, F2, B2));
	glVertex3dv(C2);
	glVertex3dv(F2);
	glVertex3dv(G2);
	glVertex3dv(B2);

	glColor3d(1, 1, 0);
	glNormal3dv(normal(K1, K2, B1));
	glVertex3dv(K1);
	glVertex3dv(K2);
	glVertex3dv(B2);
	glVertex3dv(B1);

	glNormal3dv(normal(F1, F2, C1));
	glVertex3dv(F1);
	glVertex3dv(F2);
	glVertex3dv(C2);
	glVertex3dv(C1);

	glNormal3dv(normal(D1, D2, A1));
	glVertex3dv(D1);
	glVertex3dv(D2);
	glVertex3dv(A2);
	glVertex3dv(A1);

	glColor3d(0.7, 1, 0);
	glNormal3dv(normal(B1, B2, G1));
	glVertex3dv(B1);
	glVertex3dv(B2);
	glVertex3dv(G2);
	glVertex3dv(G1);

	glNormal3dv(normal(C1, C2, E1));
	glVertex3dv(C1);
	glVertex3dv(C2);
	glVertex3dv(E2);
	glVertex3dv(E1);

	glNormal3dv(normal(A1, A2, K1));
	glVertex3dv(A1);
	glVertex3dv(A2);
	glVertex3dv(K2);
	glVertex3dv(K1);

	glColor3d(0.5, 0.3, 0.2);
	glNormal3dv(normal(G1, G2, F1));
	glVertex3dv(F1);
	glVertex3dv(F2);
	glVertex3dv(G2);
	glVertex3dv(G1);

	glNormal3dv(normal(E1, E2, D1));
	glVertex3dv(E1);
	glVertex3dv(E2);
	glVertex3dv(D2);
	glVertex3dv(D1);

	glEnd();

	//квадратик станкина
	//так как расчет освещения происходит только в вершинах
	// (закраска по Гуро)
	//то рисуем квадратик из более маленьких квадратиков


	//===============================================

	//рисуем источник света
	light.DrawLightGizmo();

	//================Сообщение в верхнем левом углу=======================

	//переключаемся на матрицу проекции
	glMatrixMode(GL_PROJECTION);
	//сохраняем текущую матрицу проекции с перспективным преобразованием
	glPushMatrix();
	//загружаем единичную матрицу в матрицу проекции
	glLoadIdentity();

	//устанавливаем матрицу паралельной проекции
	glOrtho(0, gl.getWidth() - 1, 0, gl.getHeight() - 1, 0, 1);

	//переключаемся на моделвью матрицу
	glMatrixMode(GL_MODELVIEW);
	//сохраняем матрицу
	glPushMatrix();
    //сбразываем все трансформации и настройки камеры загрузкой единичной матрицы
	glLoadIdentity();

	//отрисованное тут будет визуалзироватся в 2д системе координат
	//нижний левый угол окна - точка (0,0)
	//верхний правый угол (ширина_окна - 1, высота_окна - 1)

	
	std::wstringstream ss;
	ss << std::fixed << std::setprecision(3);
	ss << "T - " << (texturing ? L"[вкл]выкл  " : L" вкл[выкл] ") << L"текстур" << std::endl;
	ss << "L - " << (lightning ? L"[вкл]выкл  " : L" вкл[выкл] ") << L"освещение" << std::endl;
	ss << "A - " << (alpha ? L"[вкл]выкл  " : L" вкл[выкл] ") << L"альфа-наложение" << std::endl;
	ss << L"F - Свет из камеры" << std::endl;
	ss << L"G - двигать свет по горизонтали" << std::endl;
	ss << L"G+ЛКМ двигать свет по вертекали" << std::endl;
	ss << L"Коорд. света: (" << std::setw(7) <<  light.x() << "," << std::setw(7) << light.y() << "," << std::setw(7) << light.z() << ")" << std::endl;
	ss << L"Коорд. камеры: (" << std::setw(7) << camera.x() << "," << std::setw(7) << camera.y() << "," << std::setw(7) << camera.z() << ")" << std::endl;
	ss << L"Параметры камеры: R=" << std::setw(7) << camera.distance() << ",fi1=" << std::setw(7) << camera.fi1() << ",fi2=" << std::setw(7) << camera.fi2() << std::endl;
	ss << L"delta_time: " << std::setprecision(5)<< delta_time << std::endl;

	
	text.setPosition(10, gl.getHeight() - 10 - 180);
	text.setText(ss.str().c_str());
	text.Draw();

	//восстанавливаем матрицу проекции на перспективу, которую сохраняли ранее.
	glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	glMatrixMode(GL_MODELVIEW);
	glPopMatrix();
	

}   



